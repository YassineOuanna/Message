const api = "/api";
let token = localStorage.getItem("token");
let me = null;
let ws = null;
function el(id){ return document.getElementById(id); }
async function init(){
  if(token){
    const res = await fetch(`${api}/me?token=${token}`);
    if(res.ok){
      me = await res.json();
      showChat();
      connectWS();
    } else {
      localStorage.removeItem("token");
      token = null;
    }
  }
}
init();
el("btnRegister").addEventListener("click", async ()=>{
  el("reg_msg").textContent = "Please wait...";
  const payload = {
    name: el("reg_name").value,
    email: el("reg_email").value,
    contact: el("reg_contact").value,
    password: el("reg_password").value
  };
  const r = await fetch("/api/register", {method:"POST", headers:{"Content-Type":"application/json"}, body: JSON.stringify(payload)});
  const j = await r.json();
  if(r.ok) el("reg_msg").textContent = "Registered — check your email for a verification link.";
  else el("reg_msg").textContent = j.detail || JSON.stringify(j);
});
el("btnLogin").addEventListener("click", async ()=>{
  el("login_msg").textContent = "Logging in...";
  const payload = { email: el("login_email").value, password: el("login_password").value };
  const r = await fetch("/api/login", {method:"POST", headers:{"Content-Type":"application/json"}, body: JSON.stringify(payload)});
  const j = await r.json();
  if(r.ok){
    token = j.access_token;
    localStorage.setItem("token", token);
    me = { email: payload.email, name: j.name, is_admin: j.is_admin };
    showChat();
    connectWS();
  } else {
    el("login_msg").textContent = j.detail || JSON.stringify(j);
  }
});
el("btnLogout").addEventListener("click", ()=>{ localStorage.removeItem("token"); token = null; me = null; if(ws) ws.close(); window.location.reload(); });
function showChat(){ el("chatBox").classList.remove("hidden"); el("noChat").classList.add("hidden"); el("meName").textContent = me.name || ""; el("meEmail").textContent = me.email || ""; }
function addMessageBubble({sender_name, content, timestamp, mine=false}){ const d = document.createElement("div"); d.className = mine ? "self-end bg-green-500 text-white p-2 rounded-lg max-w-[80%]" : "self-start bg-white/8 text-white p-2 rounded-lg max-w-[80%]"; d.innerHTML = `<div class="text-sm font-semibold">${sender_name || "You"}</div><div class="mt-1">${escapeHtml(content)}</div><div class="text-xs opacity-60 mt-1">${new Date(timestamp).toLocaleString()}</div>`; el("messages").appendChild(d); el("messages").scrollTop = el("messages").scrollHeight; }
function escapeHtml(s){ return s.replaceAll("&","&amp;").replaceAll("<","&lt;").replaceAll(">","&gt;"); }
el("btnSend").addEventListener("click", sendMessage);
el("txtMessage").addEventListener("keydown", (e)=>{ if(e.key === "Enter" && !e.shiftKey){ e.preventDefault(); sendMessage(); }});
function connectWS(){
  if(!token) return;
  ws = new WebSocket(`${location.origin.replace(/^http/,'ws')}/ws?token=${token}`);
  ws.onopen = ()=>{ console.log("ws open"); el("send_msg").textContent = ""; }
  ws.onmessage = (ev)=>{
    const data = JSON.parse(ev.data);
    if(data.type === "message"){
      addMessageBubble({ sender_name: data.sender_name || data.sender_contact || "Visitor", content: data.content, timestamp: data.timestamp, mine: (data.sender_id === me.user_id) });
    } else if(data.type === "ack"){
      addMessageBubble({ sender_name: "You", content: el("txtMessage").value, timestamp: data.timestamp, mine: true });
      el("txtMessage").value = "";
    } else {
      console.log("ws", data);
    }
  };
  ws.onclose = ()=>{ console.log("ws closed"); el("send_msg").textContent = "Disconnected"; }
  ws.onerror = (e)=>{ console.log("ws err", e); }
}
function sendMessage(){ const txt = el("txtMessage").value.trim(); if(!txt) return; const payload = { type: "message", content: txt, sender_name: el("reg_name").value || me.name || "", sender_contact: me.email || el("reg_contact").value || "" }; if(ws && ws.readyState === WebSocket.OPEN){ ws.send(JSON.stringify(payload)); el("send_msg").textContent = "Sent"; } else { el("send_msg").textContent = "Not connected. Try reloading."; } }

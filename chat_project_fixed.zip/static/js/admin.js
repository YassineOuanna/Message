const api = "/api";
let adminToken = null;
let ws = null;
let currentUserId = null;
function el(id){ return document.getElementById(id); }
el("btnAdminLogin").addEventListener("click", async ()=>{
  el("admin_msg").textContent = "Logging in...";
  const payload = { email: el("admin_email").value, password: el("admin_password").value };
  const r = await fetch(`${api}/login`, { method:"POST", headers:{"Content-Type":"application/json"}, body: JSON.stringify(payload) });
  const j = await r.json();
  if(r.ok){
    adminToken = j.access_token;
    el("admin_msg").textContent = "Connected as admin.";
    startWS();
  } else {
    el("admin_msg").textContent = j.detail || JSON.stringify(j);
  }
});
function startWS(){
  if(!adminToken) return;
  ws = new WebSocket(`${location.origin.replace(/^http/,'ws')}/ws?token=${adminToken}`);
  ws.onopen = ()=>{ el("admin_msg").textContent = "WebSocket open."; document.getElementById("panel").classList.remove("hidden"); };
  ws.onmessage = (ev)=>{
    const data = JSON.parse(ev.data);
    if(data.type === "message"){
      addIncomingMessage(data);
      addUserToList(data.sender_id, data.sender_name, data.sender_contact);
    }
  };
  ws.onclose = ()=>{ el("admin_msg").textContent = "WebSocket closed."; };
}
function addIncomingMessage(msg){
  const c = document.createElement("div");
  c.className = "bg-white/5 p-2 rounded";
  c.innerHTML = `<div class="text-sm font-semibold">${msg.sender_name || msg.sender_contact || 'Visitor'} <span class="text-xs opacity-60">#${msg.sender_id || 'anon'}</span></div>
                 <div class="mt-1">${escapeHtml(msg.content)}</div>
                 <div class="text-xs opacity-50 mt-1">${new Date(msg.timestamp).toLocaleString()}</div>`;
  document.getElementById("convArea").appendChild(c);
  document.getElementById("convArea").scrollTop = document.getElementById("convArea").scrollHeight;
  currentUserId = msg.sender_id;
}
function addUserToList(id, name, contact){
  const usersList = document.getElementById("usersList");
  const idStr = String(id);
  if(document.getElementById("user_"+idStr)) return;
  const row = document.createElement("div");
  row.id = "user_"+idStr;
  row.className = "p-2 bg-white/6 rounded flex items-center justify-between";
  row.innerHTML = `<div><div class="font-semibold">${name || contact || "Visitor"}</div><div class="text-xs opacity-60">${contact || ""}</div></div>
                   <button class="px-3 py-1 bg-sky-500 rounded" onclick="selectUser(${idStr})">Open</button>`;
  usersList.appendChild(row);
}
window.selectUser = function(id){ currentUserId = id; document.getElementById("convArea").innerHTML = ""; }
el("btnReply").addEventListener("click", ()=>{
  const text = el("replyText").value.trim();
  if(!text || !currentUserId) return alert("Select a user and type a reply.");
  const payload = { type: "message", content: text, target_user_id: currentUserId };
  ws.send(JSON.stringify(payload));
  const c = document.createElement("div");
  c.className = "self-end bg-green-500 p-2 rounded";
  c.innerHTML = `<div class="font-semibold">You</div><div class="mt-1">${escapeHtml(text)}</div><div class="text-xs opacity-60 mt-1">${new Date().toLocaleString()}</div>`;
  document.getElementById("convArea").appendChild(c);
  el("replyText").value = "";
});
function escapeHtml(s){ return s.replaceAll("&","&amp;").replaceAll("<","&lt;").replaceAll(">","&gt;"); }

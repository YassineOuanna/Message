#!/usr/bin/env python3
import sys
from sqlmodel import Session, select
from app import engine, User, hash_password

def create_admin(email, password, name="Admin", superadmin=False):
    with Session(engine) as s:
        exists = s.exec(select(User).where(User.email == email)).first()
        if exists:
            print("User already exists") 
            return
        user = User(email=email.lower(), hashed_password=hash_password(password), name=name, is_verified=True, is_admin=True, is_superadmin=superadmin)
        s.add(user); s.commit()
        print("Admin created:", email)

if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("Usage: python create_admin.py email password [name]")
        sys.exit(1)
    create_admin(sys.argv[1], sys.argv[2], sys.argv[3] if len(sys.argv)>3 else "Admin")
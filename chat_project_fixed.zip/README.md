# Chat Project

This is a bundled FastAPI + WebSocket + SQLite chat project with admin UI, email & Twilio verification hooks.

## Quick start (local)

1. Copy `.env.example` to `.env` and edit the values.
2. Create venv and install:

```bash
python -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

3. (Optional) Create an admin user (script provided):

```bash
python scripts/create_admin.py admin@example.com StrongPassword "Admin Name"
```

4. Run server:

```bash
uvicorn app:app --reload --host 0.0.0.0 --port 8000
```

Open http://localhost:8000 and /admin

# app.py - FastAPI app (simplified bundling of previous code)
import os
import json
import uuid
import datetime
from pathlib import Path
from typing import Optional, Dict
from dotenv import load_dotenv

load_dotenv()

from fastapi import FastAPI, Request, HTTPException, WebSocket, WebSocketDisconnect, Query
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, EmailStr
from sqlmodel import SQLModel, Field, create_engine, Session, select, func
from passlib.context import CryptContext
import phonenumbers
import jwt
import smtplib
from email.message import EmailMessage

# Optional Twilio imports (only used if env configured)
try:
    from twilio.rest import Client as TwilioClient
except Exception:
    TwilioClient = None

# ----------------------
# Config
# ----------------------
SECRET_KEY = os.getenv("SECRET_KEY", "dev_secret_change_me")
ALGORITHM = os.getenv("JWT_ALGORITHM", "HS256")
ACCESS_EXPIRE_HOURS = int(os.getenv("ACCESS_TOKEN_EXPIRE_HOURS", "24"))
SITE_URL = os.getenv("SITE_URL", "http://localhost:8000")

SMTP_HOST = os.getenv("SMTP_HOST")
SMTP_PORT = int(os.getenv("SMTP_PORT", "587"))
SMTP_USER = os.getenv("SMTP_USER")
SMTP_PASS = os.getenv("SMTP_PASS")
FROM_EMAIL = os.getenv("FROM_EMAIL", SMTP_USER)

TW_SID = os.getenv("TWILIO_ACCOUNT_SID")
TW_AUTH = os.getenv("TWILIO_AUTH_TOKEN")
TW_VERIFY_SID = os.getenv("TWILIO_VERIFY_SERVICE_SID")

DEFAULT_REGION = os.getenv("DEFAULT_REGION", "US")

BASE_DIR = Path(__file__).parent
# --- Admin seed support ---
import json as _json, hashlib as _hashlib
ADMIN_SEED_PATH = BASE_DIR / "admin_seed.json"

def ensure_admin_from_seed():
    try:
        if not ADMIN_SEED_PATH.exists():
            return
        data = _json.loads(ADMIN_SEED_PATH.read_text(encoding="utf-8"))
        email = data.get("email")
        password = data.get("password")
        name = data.get("name", "Admin")
        is_super = data.get("is_superadmin", False)
        if not email or not password:
            return
        with Session(engine) as session:
            existing = session.exec(select(User).where(User.email == email)).first()
            if existing:
                # If user exists, ensure it's admin and verified
                existing.is_admin = True
                existing.is_verified = True
                if is_super:
                    existing.is_superadmin = True
                session.add(existing); session.commit()
                return
            # Create user. We use hash_password if available.
            try:
                pwd = hash_password(password)
            except Exception:
                # Fallback: store a weak marker (NOT for production). This will be updated when real hashing available.
                pwd = f"SEEDED${password}"
            user = User(email=email.lower(), hashed_password=pwd, name=name, is_verified=True, is_admin=True, is_superadmin=is_super)
            session.add(user)
            session.commit()
            print(f"Admin user created from seed: {email}")
    except Exception as e:
        print("Failed to create admin from seed:", e)

# Call this during startup

MESSAGES_DIR = BASE_DIR / "messages"
MESSAGES_DIR.mkdir(exist_ok=True)

# ----------------------
# DB setup (sqlite)
# ----------------------
DATABASE_URL = f"sqlite:///{BASE_DIR / 'app.db'}"
engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False})

# ----------------------
# Models
# ----------------------
class User(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    email: str = Field(index=True)
    hashed_password: str
    name: Optional[str] = None
    is_verified: bool = False
    is_admin: bool = False
    is_superadmin: bool = False
    created_at: datetime.datetime = Field(default_factory=lambda: datetime.datetime.utcnow())

class Message(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    sender_id: Optional[int] = None
    sender_name: Optional[str] = None
    sender_contact: Optional[str] = None
    content: str = ""
    timestamp: datetime.datetime = Field(default_factory=lambda: datetime.datetime.utcnow())
    delivered: bool = False
    archived: bool = False
    flagged: bool = False

class LoginLog(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    user_id: Optional[int] = None
    email: Optional[str] = None
    ip: Optional[str] = None
    user_agent: Optional[str] = None
    success: bool = False
    timestamp: datetime.datetime = Field(default_factory=lambda: datetime.datetime.utcnow())

class VerificationCode(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    phone: str
    code_hash: str
    expires_at: datetime.datetime

def create_db_and_tables():
    SQLModel.metadata.create_all(engine)

create_db_and_tables()

# ----------------------
# Utility: password, jwt, email, phone validation
# ----------------------
pwd_ctx = CryptContext(schemes=["bcrypt"], deprecated="auto")

def hash_password(password: str) -> str:
    return pwd_ctx.hash(password)

def verify_password(plain: str, hashed: str) -> bool:
    return pwd_ctx.verify(plain, hashed)

def create_token(data: dict, expires_hours: int = ACCESS_EXPIRE_HOURS, purpose: str = "access"):
    to_encode = data.copy()
    expire = datetime.datetime.utcnow() + datetime.timedelta(hours=expires_hours)
    to_encode.update({"exp": expire, "purpose": purpose})
    return jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)

def decode_token(token: str):
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        return payload
    except jwt.PyJWTError as e:
        raise HTTPException(status_code=401, detail="Invalid token") from e

def send_email(subject: str, body: str, to_addr: str):
    if not (SMTP_HOST and SMTP_USER and SMTP_PASS):
        return False, "SMTP not configured"
    msg = EmailMessage()
    msg["Subject"] = subject
    msg["From"] = FROM_EMAIL
    msg["To"] = to_addr
    msg.set_content(body)
    try:
        with smtplib.SMTP(SMTP_HOST, SMTP_PORT, timeout=10) as s:
            s.starttls()
            s.login(SMTP_USER, SMTP_PASS)
            s.send_message(msg)
        return True, "sent"
    except Exception as e:
        return False, str(e)

def looks_like_phone(num: str, region: str = DEFAULT_REGION) -> bool:
    try:
        pn = phonenumbers.parse(num, region)
        return phonenumbers.is_valid_number(pn)
    except Exception:
        return False

# Twilio helpers (if configured)
tw_client = None
if TW_SID and TW_AUTH and TwilioClient:
    try:
        tw_client = TwilioClient(TW_SID, TW_AUTH)
    except Exception:
        tw_client = None

def twilio_send_verification(phone):
    if not tw_client or not TW_VERIFY_SID:
        return False, "Twilio not configured"
    verification = tw_client.verify.services(TW_VERIFY_SID).verifications.create(to=phone, channel='sms')
    return True, verification.status

def twilio_check_code(phone, code):
    if not tw_client or not TW_VERIFY_SID:
        return False, "Twilio not configured"
    try:
        check = tw_client.verify.services(TW_VERIFY_SID).verification_checks.create(to=phone, code=code)
        return check.status == "approved", check.status
    except Exception as e:
        return False, str(e)

# ----------------------
# FastAPI app + static
# ----------------------
app = FastAPI()
app.mount("/static", StaticFiles(directory="static"), name="static")

@app.get("/", response_class=HTMLResponse)
def index():
    return FileResponse("static/index.html")

@app.get("/admin", response_class=HTMLResponse)
def admin_page():
    return FileResponse("static/admin.html")

# ----------------------
# API models
# ----------------------
class RegisterIn(BaseModel):
    email: EmailStr
    password: str
    name: Optional[str] = None
    contact: Optional[str] = None

class LoginIn(BaseModel):
    email: EmailStr
    password: str

# ----------------------
# Auth endpoints
# ----------------------
@app.post("/api/register")
def register(payload: RegisterIn, request: Request):
    email = payload.email.lower().strip()
    contact = (payload.contact or "").strip()

    with Session(engine) as session:
        q = session.exec(select(User).where(User.email == email)).first()
        if q:
            raise HTTPException(status_code=400, detail="Email already registered")
        user = User(
            email=email,
            hashed_password=hash_password(payload.password),
            name=payload.name,
            is_verified=False,
            is_admin=False
        )
        session.add(user)
        session.commit()
        session.refresh(user)

    token = create_token({"user_id": user.id, "email": user.email}, expires_hours=48, purpose="verify")
    verify_link = f"{SITE_URL}/api/verify?token={token}"
    subject = "Verify your email"
    body = f"Hi {user.name or user.email},\n\nClick the link to verify your email:\n\n{verify_link}\n\nThis link expires in ~48 hours."
    ok, info = send_email(subject, body, user.email)
    return {"status": "registered", "sent_verification": ok, "info": info}

@app.get("/api/verify")
def verify_email(token: str = Query(...)):
    payload = decode_token(token)
    if payload.get("purpose") != "verify":
        raise HTTPException(status_code=400, detail="Invalid token purpose")
    user_id = payload.get("user_id")
    with Session(engine) as session:
        user = session.get(User, user_id)
        if not user:
            raise HTTPException(status_code=404, detail="User not found")
        user.is_verified = True
        session.add(user)
        session.commit()
    return JSONResponse({"status":"verified"})

@app.post("/api/login")
def login(payload: LoginIn, request: Request):
    ip = request.client.host if request.client else None
    ua = request.headers.get("user-agent")
    email = payload.email.lower().strip()
    with Session(engine) as session:
        user = session.exec(select(User).where(User.email == email)).first()
        if not user:
            log = LoginLog(user_id=None, email=email, ip=ip, user_agent=ua, success=False)
            session.add(log); session.commit()
            raise HTTPException(status_code=400, detail="Invalid credentials")
        if not verify_password(payload.password, user.hashed_password):
            log = LoginLog(user_id=user.id, email=email, ip=ip, user_agent=ua, success=False)
            session.add(log); session.commit()
            raise HTTPException(status_code=400, detail="Invalid credentials")
        if not user.is_verified:
            log = LoginLog(user_id=user.id, email=email, ip=ip, user_agent=ua, success=False)
            session.add(log); session.commit()
            raise HTTPException(status_code=403, detail="Email not verified")
        log = LoginLog(user_id=user.id, email=email, ip=ip, user_agent=ua, success=True)
        session.add(log); session.commit()

        token = create_token({"user_id": user.id, "is_admin": user.is_admin, "email": user.email})
        return {"access_token": token, "token_type": "bearer", "is_admin": user.is_admin, "name": user.name}

def get_current_user(token: str = Query(None), auth: str = None):
    if auth and auth.startswith("Bearer "):
        token = auth.split(" ", 1)[1]
    if not token:
        raise HTTPException(status_code=401, detail="Missing token")
    payload = decode_token(token)
    user_id = payload.get("user_id")
    with Session(engine) as session:
        user = session.get(User, user_id)
        if not user:
            raise HTTPException(status_code=401, detail="User not found")
        return user

@app.get("/api/me")
def me(token: str = Query(None), Authorization: Optional[str] = None):
    auth_header = Authorization
    return get_current_user(token, auth_header)

# ----------------------
# Message persistence and listing
# ----------------------
def persist_message_to_db_and_file(session: Session, msg: dict):
    m = Message(
        sender_id=msg.get("sender_id"),
        sender_name=msg.get("sender_name"),
        sender_contact=msg.get("sender_contact"),
        content=msg.get("content"),
    )
    session.add(m)
    session.commit()
    session.refresh(m)
    filename = f"{m.timestamp.isoformat().replace(':','-')}_{uuid.uuid4().hex}.json"
    filepath = MESSAGES_DIR / filename
    with open(filepath, "w", encoding="utf-8") as f:
        json.dump({
            "id": m.id,
            "timestamp": m.timestamp.isoformat(),
            "sender_id": m.sender_id,
            "sender_name": m.sender_name,
            "sender_contact": m.sender_contact,
            "content": m.content
        }, f, ensure_ascii=False, indent=2)
    return m

@app.get("/api/messages")
def list_messages(page: int = 1, limit: int = 25, q: Optional[str]=None, unread: Optional[bool]=None, admin_token: str = Query(None), Authorization: Optional[str] = None):
    user = get_current_user(admin_token, Authorization)
    if not user.is_admin:
        raise HTTPException(status_code=403, detail="Admin required")
    offset = (page-1)*limit
    stmt = select(Message)
    if q:
        stmt = stmt.where(Message.content.contains(q))
    if unread is True:
        stmt = stmt.where(Message.delivered == False)
    stmt = stmt.order_by(Message.timestamp.desc()).offset(offset).limit(limit)
    with Session(engine) as s:
        rows = s.exec(stmt).all()
        total = s.exec(select(func.count()).select_from(Message)).one()
        return {"messages":[{"id":r.id,"timestamp":r.timestamp.isoformat(),"sender_name":r.sender_name,"content":r.content} for r in rows], "page":page, "limit":limit, "total": total}

# ----------------------
# WebSocket real-time chat (simplified)
# ----------------------
user_conn_map: Dict[int, WebSocket] = {}
admin_conn: Optional[WebSocket] = None

@app.websocket("/ws")
async def ws_endpoint(websocket: WebSocket):
    await websocket.accept()
    token = websocket.query_params.get("token")
    if not token:
        await websocket.send_json({"type":"error", "detail":"Missing token"})
        await websocket.close()
        return
    try:
        payload = decode_token(token)
    except HTTPException:
        await websocket.send_json({"type":"error", "detail":"Invalid token"})
        await websocket.close()
        return
    user_id = payload.get("user_id")
    is_admin = payload.get("is_admin", False)
    try:
        if is_admin:
            global admin_conn
            admin_conn = websocket
            await websocket.send_json({"type":"info","detail":"Admin connected"})
        else:
            user_conn_map[user_id] = websocket
            await websocket.send_json({"type":"info","detail":"User connected", "user_id": user_id})

        while True:
            data_text = await websocket.receive_text()
            data = json.loads(data_text)
            if data.get("type") == "message":
                content = data.get("content", "").strip()
                sender_name = data.get("sender_name")
                sender_contact = data.get("sender_contact")
                with Session(engine) as session:
                    saved = persist_message_to_db_and_file(session, {
                        "sender_id": user_id if not is_admin else None,
                        "sender_name": sender_name,
                        "sender_contact": sender_contact,
                        "content": content
                    })
                payload_out = {
                    "type": "message",
                    "id": saved.id,
                    "timestamp": saved.timestamp.isoformat(),
                    "sender_id": saved.sender_id,
                    "sender_name": saved.sender_name,
                    "sender_contact": saved.sender_contact,
                    "content": saved.content
                }
                if is_admin:
                    target = data.get("target_user_id")
                    if target and int(target) in user_conn_map:
                        try:
                            await user_conn_map[int(target)].send_json(payload_out)
                        except Exception:
                            pass
                else:
                    if admin_conn:
                        try:
                            await admin_conn.send_json(payload_out)
                        except Exception:
                            pass
                    try:
                        await websocket.send_json({"type":"ack","id": saved.id, "timestamp": saved.timestamp.isoformat()})
                    except Exception:
                        pass
            else:
                await websocket.send_json({"type":"error","detail":"Unknown message type"})
    except WebSocketDisconnect:
        if is_admin:
            admin_conn = None
        else:
            if user_id in user_conn_map:
                del user_conn_map[user_id]

# ----------------------
# Simple form endpoint (compat)
# ----------------------
class SimpleMsg(BaseModel):
    name: Optional[str]
    contact: str
    message: str

@app.post("/message")
def receive_message(payload: SimpleMsg, request: Request):
    contact = payload.contact.strip()
    if ("@" in contact):
        pass
    elif not looks_like_phone(contact):
        raise HTTPException(status_code=422, detail="Contact must be a valid email or phone number")

    with Session(engine) as session:
        saved = persist_message_to_db_and_file(session, {
            "sender_id": None,
            "sender_name": payload.name,
            "sender_contact": contact,
            "content": payload.message
        })
    return {"status":"saved", "id": saved.id}

@app.on_event("startup")
def startup_event():
    print("App starting, DB ready.")
    try:
        ensure_admin_from_seed()
    except Exception as _e:
        print('ensure_admin_from_seed failed:', _e)
